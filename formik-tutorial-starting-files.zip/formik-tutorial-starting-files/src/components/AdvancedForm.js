const AdvancedForm = () => {
  return (
    <form autoComplete="off">
      <label htmlFor="username">Username</label>
      <input id="username" type="text" placeholder="Enter your username" />
    </form>
  );
};
export default AdvancedForm;
